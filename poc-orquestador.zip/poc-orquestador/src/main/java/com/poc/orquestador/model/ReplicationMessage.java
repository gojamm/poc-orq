package com.poc.orquestador.model;

import com.poc.orquestador.service.OperationsService;

//TODO validacion
public record ReplicationMessage(String messageId, OperationsService.ReplicationType type, String content){}
