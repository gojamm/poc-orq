package com.poc.orquestador.config;

import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Declarables;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Configuration
public class BrokerConfig {

    @Value("${rabbitmq.config.host}")
    private String host;

    @Value("${rabbitmq.config.username}")
    private String user;

    @Value("${rabbitmq.config.password}")
    private String password;

    @Value("${rabbitmq.config.port}")
    private Integer port;

    @Bean
    public Declarables bindings() {
//TODO reemplazar valores por env vars
        Queue pendingQueue = new Queue("replicacion.oyd.proceso.pendientes", true);
        Queue activeQueue = new Queue("replicacion.oyd.proceso.activas", true,
                false, false, Map.of("message-ttl", 300000));
        /*Queue completedQueue = new Queue("replicacion.oyd.proceso.completadas", true,
                false, false, Map.of("x-single-active-consumer", true));*/
        DirectExchange replicationExchange = new DirectExchange("replicacion.oyd.direct");

        return new Declarables(
                pendingQueue,
                //completedQueue,
                activeQueue,
                replicationExchange,
                BindingBuilder.bind(pendingQueue).to(replicationExchange)
                        .with("pending"),
                BindingBuilder.bind(activeQueue).to(replicationExchange)
                        .with("active")//,
                /*BindingBuilder.bind(completedQueue).to(replicationExchange)
                        .with("completed")*/
        );
    }

    @Bean
    public ConnectionFactory connectionFactory() {
        CachingConnectionFactory factory = new CachingConnectionFactory();
        factory.setUsername(user);
        factory.setPassword(password);
        factory.setHost(host);
        factory.setPort(port);
        return factory;
    }

    @Bean
    public SimpleRabbitListenerContainerFactory listenerContainerFactory(ConnectionFactory connectionFactory) {
        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConnectionFactory(connectionFactory);
        return factory;
    }
}