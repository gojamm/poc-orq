package com.poc.orquestador.model;

public record BrokerMessage(String exchange, String routingKey, String message, String messageId, String expiration){}
