package com.poc.orquestador.scheduler;

import com.poc.orquestador.exception.BusyReplicationException;
import com.poc.orquestador.service.OperationsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class PendingScheduler {

    @Autowired
    OperationsService operationsService;

    //TODO reemplazar variable por env var
    @Scheduled(fixedDelay = 5000)
    public void pendingScheduler(){
        try {
            operationsService.processPending();
        } catch (BusyReplicationException e) {
            // se silencia mensaje de activos en proceso
        }
    }

}
