package com.poc.orquestador.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sfn.SfnClient;
import software.amazon.awssdk.services.sfn.model.SfnException;
import software.amazon.awssdk.services.sfn.model.StartExecutionRequest;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

@Service
public class ReplicationService {
//TODO reemplazar con funcionalidad final

    @Value("${replicador.pn.deployment.service.host:localhost}")
    String hostReplicadorPn;

    @Value("${replicador.pn.deployment.service.port:8888}")
    String portReplicadorPn;

    public void executePN(String message){
        //TODO implementar
        String replicadorUrl = "http://"+hostReplicadorPn+":"+portReplicadorPn+"/replicadorpn/start";
        System.out.println("llamando ..."+replicadorUrl);
        Mono<String> client = WebClient.builder()
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .build()
                .post()
                //.uri("http://replicador-pn-deployment.default.svc.clouster.local/replicadorpn/start")
                .uri(replicadorUrl)
                .bodyValue(message)
                .retrieve()
                .bodyToMono(String.class)
                .doOnError(throwable -> System.out.println("Error: "+ throwable));
        client.subscribe(s -> System.out.println("Mensaje enviado a replicador PN..."+s.getBytes(StandardCharsets.UTF_8)));
    }

    public void executePJ(String message){
        //TODO implementar

        SfnClient sfnClient = SfnClient.builder()
                .region(Region.US_EAST_1)
                .credentialsProvider(ProfileCredentialsProvider.create())
                .build();

        UUID uuid = UUID.randomUUID();
        String uuidValue = uuid.toString();

        try {
            StartExecutionRequest executionRequest = StartExecutionRequest.builder()
                    .input(message)
                    .stateMachineArn("arn.step.function.......")
                    .name(uuidValue)
                    .build();

            sfnClient.startExecution(executionRequest);

        } catch (SfnException e) {
            System.err.println(e.awsErrorDetails().errorMessage());
            System.exit(1);
        }

    }
}
