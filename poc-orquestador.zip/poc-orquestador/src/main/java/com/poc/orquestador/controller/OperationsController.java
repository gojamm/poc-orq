package com.poc.orquestador.controller;

import com.poc.orquestador.model.ReplicationMessage;
import com.poc.orquestador.service.OperationsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Api(value = "Orquestador replicacion OyD")
@RestController
@RequestMapping("/replications")
public class OperationsController {

    @Autowired
    OperationsService operationsService;

    @ApiOperation(value = "Publicar una replicacion para que sea procesada")
    @PostMapping(value = "/pending/publish")
    public ResponseEntity<String> publishPending(@RequestBody ReplicationMessage replicationMessage) {
        operationsService.publishMessage(
                replicationMessage.messageId(),
                replicationMessage.content(),
                OperationsService.ProcessStatus.PENDING);
        return ResponseEntity.ok("ok");
    }

    //TODO analizar si este servicio se puede cambiar a GET solo enviando el messageId
    @ApiOperation(value = "Publicar una replicacion para que ya fue procesada")
    @PostMapping(value = "/completed/publish")
    public ResponseEntity<String> publishCompleted(@RequestBody ReplicationMessage replicationMessage) {
        operationsService.processCompleted(replicationMessage.messageId());
        return ResponseEntity.ok("ok");
    }

    @ApiOperation(value = "Ver lista de replicaciones pendientes")
    @GetMapping(value = "/pending/list")
    public ResponseEntity<List<String>> listPending() {
        return ResponseEntity.ok(new ArrayList<>());
    }
}