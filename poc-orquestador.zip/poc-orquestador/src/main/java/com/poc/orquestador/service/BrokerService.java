package com.poc.orquestador.service;

import com.poc.orquestador.model.BrokerMessage;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.GetResponse;
import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.*;

@Component
public class BrokerService {
    @Autowired
    private RabbitTemplate template;

    @Autowired
    private AmqpAdmin amqpAdmin;

    public void publish(BrokerMessage brokerMessage) {
        AMQP.BasicProperties.Builder builder = new AMQP.BasicProperties().builder();
        builder
                .headers(Map.of(
                        "messageId", brokerMessage.messageId(),
                        "date", new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())
                ));
        if (!"-1".equals(brokerMessage.expiration())) {
            builder.expiration(brokerMessage.expiration());
        }
        template.execute(channel -> {
            channel.basicPublish(brokerMessage.exchange(),
                    brokerMessage.routingKey(),
                    builder.build(),
                    brokerMessage.message().getBytes());
            return null;
        });
    }

    //TODO revisar error generado en broker
    //borrar metodo
    public List<GetResponse> _getMessages(String queue, Integer limit, boolean ack) {
        //System.out.println("[broker] getMessages:");
        List<GetResponse> messagesList = new ArrayList<>();
        return template.execute(channel -> {
            channel.basicQos(1);
            long deliveryTag = 0;
            int count = 0;
            do {
                if (count >= limit && limit != -1) {
                    if (ack) {
                        System.out.println("[broker] hace ack de msg-dt:" + deliveryTag);
                        channel.basicAck(deliveryTag, false);

                    } else {
                        System.out.println("[broker] hace nack de msg-dt:" + deliveryTag);
                        channel.basicNack(deliveryTag, false, true);
                    }
                    break;
                }
                GetResponse result = channel.basicGet(queue, false);
                if (Objects.isNull(result)) break;

                messagesList.add(result);
                deliveryTag = result.getEnvelope().getDeliveryTag();
                System.out.println("[broker][loop] nack:" + deliveryTag);
                channel.basicNack(deliveryTag, false, false);
                count++;
            } while (true);

            if (!ack) {
                System.out.println("[broker] hace nack de msg-dt (fin):" + deliveryTag);
                channel.basicNack(deliveryTag, true, true);
            }
            //System.out.println("[broker] fin getMessages");
            return messagesList;
        });
    }

    public List<GetResponse> getMessages(String queue, Integer limit, boolean ack) {
        List<GetResponse> messagesList = new ArrayList<>();
        return template.execute(channel -> {
            long deliveryTag;
            int count = 0;
            channel.basicQos(1);

            do {
                GetResponse result = channel.basicGet(queue, false);
                if(Objects.isNull(result)){
                    break;
                }

                deliveryTag = result.getEnvelope().getDeliveryTag();
                messagesList.add(result);

                if(ack){
                    channel.basicAck(deliveryTag, false);
                }else{
                    channel.basicNack(deliveryTag, false, true);
                }
                count++;

                if(count == limit){
                    break;
                }
            } while (true);

            return messagesList;

        });
    }

    public Integer getMessagesCount(String queue) {
        return (Integer) amqpAdmin.getQueueProperties(queue).get("QUEUE_MESSAGE_COUNT");
    }

    public void removeMessageById(String queue, String messageId) {
        template.execute(channel -> {
            channel.basicQos(100);
            long deliveryTag = 0;
            do {

                GetResponse msg = channel.basicGet(queue, false);
                if (Objects.isNull(msg)) {
                    break;
                }
                deliveryTag = msg.getEnvelope().getDeliveryTag();
                if (messageId.equals(msg.getProps().getHeaders().get("messageId").toString())) {
                    channel.basicAck(deliveryTag, false);
                    break;
                }
            } while (true);
            channel.basicNack(deliveryTag, true, true);
            return null;
        });
    }

}
