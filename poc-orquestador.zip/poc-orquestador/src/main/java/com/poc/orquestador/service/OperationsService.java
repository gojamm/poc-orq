package com.poc.orquestador.service;

import com.poc.orquestador.exception.BusyReplicationException;
import com.poc.orquestador.model.BrokerMessage;
import com.rabbitmq.client.GetResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;

@Service
public class OperationsService {

    @Autowired
    private BrokerService brokerService;

    @Autowired
    private ReplicationService replicationService;

    //TODO reemplazar valor por env var
    public void publishMessage(String messageId, String message, ProcessStatus status) {
        System.out.println("[publishMessage] Publica msg en rk..."+status.name()+"\n\n");
        brokerService.publish(
                new BrokerMessage(
                        "replicacion.oyd.direct",
                        status.name().toLowerCase(),
                        message,
                        messageId,
                        ProcessStatus.ACTIVE.equals(status)?"300000":"-1"
                ));
    }

    public void processPending() throws BusyReplicationException {
        Integer active = getActiveProcess();

        if (active == 0) {
            Optional<GetResponse> message = Optional.ofNullable(getNextPendingMessage());

            if (message.isPresent()) {

                String body = new String(message.get().getBody(), StandardCharsets.UTF_8);
                String messageId = message.get().getProps().getHeaders().get("messageId").toString();

                System.out.println("[ProcessPending] Se obtiene siguiente mensaje:"+message.get().getProps().getHeaders().get("messageId").toString());

                //TODO cambiar a tipo de replicacion
                startReplication(ReplicationType.PN, body);
                publishMessage(messageId, body, ProcessStatus.ACTIVE);
            }
        }else{
            throw new BusyReplicationException("No se puede iniciar la replicacion, " +
                    "una replicacion se encuentra en curso");
        }
    }

    //TODO reemplazar variable por env var
    public GetResponse getNextPendingMessage() {
        List<GetResponse> messagesList = brokerService.getMessages("replicacion.oyd.proceso.pendientes", 1, true);
        //System.out.println("Mensajes pendientes encontrados:"+messagesList.size());
        if (!messagesList.isEmpty()) {
            return messagesList.get(0);
        }
        return null;
    }

    private Integer getActiveProcess() {
        //TODO reemplazar variable por env var
        return brokerService.getMessagesCount("replicacion.oyd.proceso.activas");
    }

    public void startReplication(ReplicationType type, String message) {
        //TODO reemplazar por logger
        System.out.println("[StartReplication] se inicia ejecucion de replicacion con mensaje pendiente:" + message);

        if(ReplicationType.PN.equals(type)){
            replicationService.executePN(message);
        }else{
            replicationService.executePJ(message);
        }
    }

    public void processCompleted(String messageId) {
        //TODO reemplazar variable por env var
        System.out.println("[ProcessCompleted] Se recibe peticion de replicacion finalizada..."+messageId);
        brokerService.removeMessageById("replicacion.oyd.proceso.activas",messageId);
        System.out.println("[ProcessCompleted] ---> fin\n\n");
    }

    public enum ProcessStatus {
        PENDING, ACTIVE
    }

    //TODO validar si el enum puede utilizarse en request
    public enum ReplicationType {
        PN, PJ
    }
}