package com.poc.orquestador.exception;

public class BusyReplicationException extends Exception{
    public BusyReplicationException(String errorMessage) {
        super(errorMessage);
    }
}
