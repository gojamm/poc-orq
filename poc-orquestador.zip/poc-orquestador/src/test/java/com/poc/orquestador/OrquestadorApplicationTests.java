package com.poc.orquestador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrquestadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
